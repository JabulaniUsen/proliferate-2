
// src/config.js
export const BASE_URL = 'http://203.161.58.119:9080/proliferate/api/v1';
