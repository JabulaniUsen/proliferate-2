export const subjectsList = [
  { id: 1, value: "mathematics", label: "Mathematics" },
  { id: 2, value: "english", label: "English" },
  { id: 3, value: "biology", label: "Biology" },
  { id: 4, value: "chemistry", label: "Chemistry" },
  { id: 5, value: "physics", label: "Physics" },
  { id: 6, value: "STEM", label: "STEM (Coding & Robotics)" },
  { id: 7, value: "french", label: "French" },
  { id: 8, value: "spanish", label: "Spanish" },
  { id: 9, value: "german", label: "German" },
];
