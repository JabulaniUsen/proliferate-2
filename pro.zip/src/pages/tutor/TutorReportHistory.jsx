import React from "react";

const TutorReportHistory = () => {
  return (
    <div>
      <div className="heading">
        <h1>Report | History</h1>
      </div>
      <div className="content"></div>
    </div>
  );
};

export default TutorReportHistory;
